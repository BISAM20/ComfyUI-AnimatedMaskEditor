import { app } from "../../scripts/app.js";
import { ComfyWidgets } from "../../scripts/widgets.js";
import { api } from "../../scripts/api.js";

// Add custom widget to the node
app.registerExtension({
    name: "AnimatedMaskDrawer.LaunchEditor",
    
    async beforeRegisterNodeDef(nodeType, nodeData, app) {
        if (nodeData.name === "AnimatedMaskDrawer") {
            
            // Add button to launch editor
            const onNodeCreated = nodeType.prototype.onNodeCreated;
            nodeType.prototype.onNodeCreated = function() {
                const r = onNodeCreated ? onNodeCreated.apply(this, arguments) : undefined;
                
                // Add "Launch Editor" button
                const launchBtn = this.addWidget("button", "🎨 Launch Mask Editor", null, () => {
                    openMaskEditor();
                });
                
                // Add status text
                const statusWidget = this.addWidget("text", "status", "Ready", () => {}, {
                    multiline: false
                });
                statusWidget.disabled = true;
                
                // Store reference for updates
                this.maskEditorStatus = statusWidget;
                
                return r;
            }
            
            // Override execution to show status
            const onExecuted = nodeType.prototype.onExecuted;
            nodeType.prototype.onExecuted = function(message) {
                if (onExecuted) {
                    onExecuted.apply(this, arguments);
                }
                
                if (this.maskEditorStatus) {
                    try {
                        const maskData = message.mask_data_json ? JSON.parse(message.mask_data_json) : null;
                        const shapeCount = maskData?.shapes?.length || 0;
                        this.maskEditorStatus.value = `✔ Generated (${shapeCount} shapes)`;
                    } catch (e) {
                        this.maskEditorStatus.value = "✔ Masks generated";
                    }
                }
            }
        }
    }
});

// Open mask editor in new window
function openMaskEditor() {
    const width = 1400;
    const height = 800;
    const left = (screen.width - width) / 2;
    const top = (screen.height - height) / 2;
    
    const editorWindow = window.open(
        '/animated_mask_editor',
        'MaskEditor',
        `width=${width},height=${height},left=${left},top=${top},resizable=yes`
    );
    
    if (!editorWindow) {
        alert('Please allow pop-ups for this site to use the Mask Editor');
    }
}

// Add custom styling
const style = document.createElement('style');
style.textContent = `
    .comfy-widget button[name="🎨 Launch Mask Editor"] {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        font-weight: bold;
        border: none;
        padding: 10px;
        cursor: pointer;
        border-radius: 4px;
        transition: transform 0.2s;
        margin-bottom: 5px;
    }
    
    .comfy-widget button[name="🎨 Launch Mask Editor"]:hover {
        transform: scale(1.05);
    }
`;
document.head.appendChild(style);
